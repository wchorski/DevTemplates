var o=document.getElementById("mouse-follow");document.addEventListener("mousemove",e=>{o.style.cssText=`
    left: ${e.clientX-25}px;
    top:  ${e.clientY-25}px;
  `});console.log("main.js loaded");
//# sourceMappingURL=main.js.map
